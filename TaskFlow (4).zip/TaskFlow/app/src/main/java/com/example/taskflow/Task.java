package com.example.taskflow;

import org.json.JSONException;
import org.json.JSONObject;

/** A single to-do item. */
public class Task {

    public static final int HIGH = 0;
    public static final int MEDIUM = 1;
    public static final int LOW = 2;

    private final long id;
    private String title;
    private boolean done;
    private int priority;

    public Task(long id, String title, boolean done, int priority) {
        this.id = id;
        this.title = title;
        this.done = done;
        this.priority = priority;
    }

    /** Creates a brand-new, unfinished task (the timestamp doubles as a unique id). */
    public static Task create(String title, int priority) {
        return new Task(System.currentTimeMillis(), title, false, priority);
    }

    public long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public boolean isDone() { return done; }
    public void setDone(boolean done) { this.done = done; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("done", done);
        o.put("priority", priority);
        return o;
    }

    public static Task fromJson(JSONObject o) throws JSONException {
        return new Task(
                o.getLong("id"),
                o.getString("title"),
                o.optBoolean("done", false),
                o.optInt("priority", MEDIUM));
    }
}
