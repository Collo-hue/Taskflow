package com.example.taskflow;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Saves and loads the task list as a JSON string inside SharedPreferences. */
public final class TaskStorage {

    private static final String PREFS = "taskflow_prefs";
    private static final String KEY_TASKS = "tasks";

    private TaskStorage() { }

    public static void save(Context context, List<Task> tasks) {
        JSONArray array = new JSONArray();
        try {
            for (Task t : tasks) {
                array.put(t.toJson());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_TASKS, array.toString())
                .apply();
    }

    public static List<Task> load(Context context) {
        List<Task> result = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_TASKS, null);
        if (json == null) {
            return result;
        }
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                result.add(Task.fromJson(array.getJSONObject(i)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
}
