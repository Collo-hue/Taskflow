package com.example.taskflow;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.List;

/** Custom adapter: checkbox, title, priority dot + label and a delete icon. */
public class TaskAdapter extends ArrayAdapter<Task> {

    /** Lets the Activity react to clicks inside a row. */
    public interface Listener {
        void onToggle(Task task, boolean done);
        void onDelete(Task task);
        void onEdit(Task task);
    }

    private final LayoutInflater inflater;
    private final Listener listener;
    private final String[] priorityNames;

    public TaskAdapter(Context context, List<Task> tasks, Listener listener) {
        super(context, 0, tasks);
        this.inflater = LayoutInflater.from(context);
        this.listener = listener;
        this.priorityNames = context.getResources().getStringArray(R.array.priority_names);
    }

    private static class Holder {
        CheckBox done;
        TextView title;
        View dot;
        TextView priority;
        ImageButton delete;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_task, parent, false);
            h = new Holder();
            h.done = convertView.findViewById(R.id.cbDone);
            h.title = convertView.findViewById(R.id.tvTitle);
            h.dot = convertView.findViewById(R.id.viewDot);
            h.priority = convertView.findViewById(R.id.tvPriority);
            h.delete = convertView.findViewById(R.id.btnDelete);
            convertView.setTag(h);
        } else {
            h = (Holder) convertView.getTag();
        }

        final Task task = getItem(position);
        if (task == null) {
            return convertView;
        }

        // Title + strike-through when finished
        h.title.setText(task.getTitle());
        if (task.isDone()) {
            h.title.setPaintFlags(h.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            h.title.setTextColor(ContextCompat.getColor(getContext(), R.color.text_done));
        } else {
            h.title.setPaintFlags(h.title.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            h.title.setTextColor(ContextCompat.getColor(getContext(), R.color.text_primary));
        }

        // Checkbox: detach the listener before changing state (rows are recycled)
        h.done.setOnCheckedChangeListener(null);
        h.done.setChecked(task.isDone());
        h.done.setOnCheckedChangeListener((button, isChecked) -> listener.onToggle(task, isChecked));

        // Priority dot + label
        int colorRes;
        switch (task.getPriority()) {
            case Task.HIGH:   colorRes = R.color.priority_high; break;
            case Task.LOW:    colorRes = R.color.priority_low;  break;
            default:          colorRes = R.color.priority_medium; break;
        }
        int color = ContextCompat.getColor(getContext(), colorRes);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(color);
        h.dot.setBackground(dot);
        h.priority.setText(priorityNames[task.getPriority()]);
        h.priority.setTextColor(color);

        h.delete.setOnClickListener(v -> listener.onDelete(task));

        // Tap or long-press anywhere on the row to edit the task
        convertView.setOnClickListener(v -> listener.onEdit(task));
        convertView.setOnLongClickListener(v -> {
            listener.onEdit(task);
            return true;
        });

        return convertView;
    }
}
