package com.example.taskflow;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TaskAdapter.Listener {

    /**
     * Display order: open tasks first (High -> Medium -> Low),
     * finished tasks sink to the bottom. Ties are broken by creation time.
     */
    private static final Comparator<Task> ORDER = (a, b) -> {
        if (a.isDone() != b.isDone()) {
            return a.isDone() ? 1 : -1;
        }
        if (a.getPriority() != b.getPriority()) {
            return Integer.compare(a.getPriority(), b.getPriority());
        }
        return Long.compare(a.getId(), b.getId());
    };

    private final List<Task> tasks = new ArrayList<>();
    private TaskAdapter adapter;
    private TextView tvSummary;
    private TextView tvEmpty;
    private View root;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        tvSummary = findViewById(R.id.tvSummary);
        tvEmpty = findViewById(R.id.tvEmpty);
        ListView listView = findViewById(R.id.listView);
        FloatingActionButton fab = findViewById(R.id.fabAdd);

        tasks.addAll(TaskStorage.load(this));
        adapter = new TaskAdapter(this, tasks, this);
        listView.setAdapter(adapter);

        fab.setOnClickListener(v -> showTaskDialog(null));

        refresh();
    }

    // ------------------------------------------------------------------
    // Adapter callbacks
    // ------------------------------------------------------------------

    @Override
    public void onToggle(Task task, boolean done) {
        task.setDone(done);
        refresh();
    }

    @Override
    public void onEdit(Task task) {
        showTaskDialog(task);
    }

    @Override
    public void onDelete(final Task task) {
        tasks.remove(task);
        refresh();

        Snackbar.make(root, R.string.task_deleted, Snackbar.LENGTH_LONG)
                .setAction(R.string.undo, v -> {
                    tasks.add(task);
                    refresh();
                })
                .show();
    }

    // ------------------------------------------------------------------
    // Add / edit dialog
    // ------------------------------------------------------------------

    /** @param existing the task to edit, or null to add a new one. */
    private void showTaskDialog(@Nullable final Task existing) {
        View view = getLayoutInflater().inflate(R.layout.dialog_task, null);
        final EditText etTitle = view.findViewById(R.id.etTitle);
        final Spinner spPriority = view.findViewById(R.id.spPriority);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.priority_names, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPriority.setAdapter(spinnerAdapter);

        if (existing != null) {
            etTitle.setText(existing.getTitle());
            etTitle.setSelection(etTitle.length());
            spPriority.setSelection(existing.getPriority());
        } else {
            spPriority.setSelection(Task.MEDIUM);
        }

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? R.string.dialog_add : R.string.dialog_edit)
                .setView(view)
                .setPositiveButton(R.string.save, null)   // set below so we can keep it open
                .setNegativeButton(android.R.string.cancel, null)
                .create();

        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        dialog.setOnShowListener(d ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    String title = etTitle.getText().toString().trim();

                    // Input validation: keep the dialog open and show an error
                    if (title.isEmpty()) {
                        etTitle.setError(getString(R.string.error_empty));
                        etTitle.requestFocus();
                        return;
                    }

                    int priority = spPriority.getSelectedItemPosition();
                    if (existing == null) {
                        tasks.add(Task.create(title, priority));
                    } else {
                        existing.setTitle(title);
                        existing.setPriority(priority);
                    }
                    refresh();
                    dialog.dismiss();
                }));

        dialog.show();
    }

    // ------------------------------------------------------------------
    // Refresh UI + persist
    // ------------------------------------------------------------------

    private void refresh() {
        Collections.sort(tasks, ORDER);
        adapter.notifyDataSetChanged();
        TaskStorage.save(this, tasks);

        int remaining = 0;
        for (Task t : tasks) {
            if (!t.isDone()) remaining++;
        }
        tvSummary.setText(getResources().getQuantityString(
                R.plurals.tasks_remaining, remaining, remaining));

        tvEmpty.setVisibility(tasks.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
