# TaskFlow - A Simple Task Manager

A to-do list app for Android (Java). Add, complete, edit and delete tasks;
everything is saved on the device with SharedPreferences (JSON via JSONArray).

## How to run
1. Open Android Studio -> File -> Open -> select the `TaskFlow` folder.
2. Let Gradle sync (Android Studio will create the Gradle wrapper if missing).
3. Press Run on an emulator or a real phone (Android 7.0+ / API 24+).

## Features
- ListView with a custom ArrayAdapter (checkbox, title, priority dot + label, delete icon)
- Floating Action Button opens an AlertDialog (EditText + priority Spinner)
- Tick a task: text is struck through and it moves to the bottom
- Long-press a task to edit it (dialog is pre-filled)
- Delete icon removes a task
- "X tasks remaining" summary at the top
- Tasks survive closing the app (SharedPreferences + JSON)

## Extras
- Undo option (Snackbar) after deleting a task
- Open tasks are sorted High -> Low priority
- Empty-state message and input validation

## Project layout
- `Task.java`         - model + JSON conversion
- `TaskStorage.java`  - SharedPreferences save/load
- `TaskAdapter.java`  - custom row layout and click callbacks
- `MainActivity.java` - list, dialog, sorting, undo, summary
